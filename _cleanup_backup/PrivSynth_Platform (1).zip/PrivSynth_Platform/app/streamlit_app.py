"""PrivSynth web dashboard (Streamlit).

Run from the project root:
    streamlit run app/streamlit_app.py
"""
from __future__ import annotations

import io
import sys
import zipfile
from pathlib import Path

import pandas as pd
import streamlit as st

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from privsynth.config import load_config, logo_path  # noqa: E402
from privsynth.data import detect_schema, load_csv  # noqa: E402
from privsynth.generators import DISPLAY_NAMES  # noqa: E402
from privsynth.imbalance import class_distribution, imbalance_ratio  # noqa: E402
from privsynth.pipeline import run_pipeline  # noqa: E402

st.set_page_config(page_title="PrivSynth | AIVONEX", page_icon="🛡️", layout="wide")
CFG = load_config()
LOGO = logo_path(CFG)

# ---------------- sidebar ----------------
with st.sidebar:
    if LOGO:
        st.image(str(LOGO), width=150)
    st.markdown("### PrivSynth")
    st.caption("Privacy aware synthetic data generation and evaluation · AIVONEX SMC PVT LTD")
    uploaded = st.file_uploader("Upload a CSV dataset", type=["csv"])
    use_demo = st.checkbox("Use the demo clinical dataset", value=uploaded is None)

st.title("Privacy Aware Synthetic Data Platform")

if uploaded is not None:
    df = load_csv(io.BytesIO(uploaded.getvalue()))
    data_name = uploaded.name
elif use_demo and (ROOT / CFG["data"]["input_csv"]).exists():
    df = load_csv(ROOT / CFG["data"]["input_csv"])
    data_name = Path(CFG["data"]["input_csv"]).name
else:
    st.info("Upload a CSV file in the sidebar, or run `python scripts/make_sample_data.py` to create the demo dataset.")
    st.stop()

tab_data, tab_cfg, tab_res = st.tabs(["1 · Dataset and schema", "2 · Generate", "3 · Results"])

# ---------------- tab 1 ----------------
with tab_data:
    st.subheader(f"{data_name}: {len(df):,} rows × {df.shape[1]} columns")
    st.dataframe(df.head(50), width="stretch")
    default_t = CFG["data"]["target_column"] if CFG["data"]["target_column"] in df.columns else df.columns[-1]
    target = st.selectbox("Target column (for class balancing and downstream ML)", ["(none)"] + list(df.columns),
                          index=list(df.columns).index(default_t) + 1)
    target = None if target == "(none)" else target
    drop = st.multiselect("Columns to drop (IDs, names, free text)", list(df.columns))
    schema = detect_schema(df, target, int(CFG["data"]["max_categories"]), drop)
    st.markdown("#### Detected schema")
    st.dataframe(schema.summary_frame(), width="stretch", hide_index=True)
    if schema.task == "classification":
        c1, c2 = st.columns([2, 1])
        c1.dataframe(class_distribution(df.dropna(subset=[target]), target), hide_index=True)
        c2.metric("Imbalance ratio (majority / minority)", f"{imbalance_ratio(df.dropna(subset=[target]), target):.1f}")
    elif schema.task == "regression":
        st.info("Numeric target detected, downstream evaluation will use regression metrics.")

# ---------------- tab 2 ----------------
with tab_cfg:
    gens = st.multiselect("Generators", list(DISPLAY_NAMES), default=CFG["generators"]["enabled"],
                          format_func=lambda k: DISPLAY_NAMES[k])
    c1, c2, c3 = st.columns(3)
    epochs = c1.number_input("CTGAN / TVAE epochs", 10, 3000, int(CFG["generators"]["ctgan"]["epochs"]), 10)
    steps = c2.number_input("TabDDPM training steps", 200, 50000, int(CFG["generators"]["tabddpm"]["steps"]), 200)
    holdout = c3.slider("Holdout share (never seen by generators)", 0.1, 0.5, float(CFG["data"]["holdout_size"]), 0.05)
    c4, c5 = st.columns(2)
    strategy = c4.selectbox("Class imbalance handling", ["none", "balance", "custom"],
                            disabled=schema.task != "classification",
                            help="none keeps real proportions, balance makes classes equal, custom uses your ratios")
    n_rows = c5.number_input("Synthetic rows (0 = same as real training rows)", 0, 1_000_000, 0, 500)
    ratios = {}
    if strategy == "custom" and schema.task == "classification":
        st.caption("Custom class ratios (they are normalised to sum to 1)")
        cols = st.columns(min(len(schema.columns[target].categories), 6))
        for i, cls in enumerate(schema.columns[target].categories):
            ratios[cls] = cols[i % len(cols)].number_input(f"{target} = {cls}", 0.0, 1.0,
                                                          round(1 / len(schema.columns[target].categories), 2), 0.05)
    if st.button("Generate and evaluate", type="primary", disabled=not gens):
        bar = st.progress(0.0, text="Starting")
        overrides = {
            "data": {"target_column": target, "holdout_size": holdout, "drop_columns": drop},
            "generators": {"enabled": gens, "ctgan": {"epochs": int(epochs)}, "tvae": {"epochs": int(epochs)},
                           "tabddpm": {"steps": int(steps)}},
            "imbalance": {"strategy": strategy, "num_rows": int(n_rows) or None, "custom_ratios": ratios},
        }
        try:
            run = run_pipeline(CFG, overrides, data=df, progress=lambda m, f: bar.progress(min(f, 1.0), text=m))
            st.session_state["run"] = run
            st.success(f"Finished {run['run_id']}. Open the Results tab.")
        except Exception as e:
            st.error(f"Run failed: {e}")

# ---------------- tab 3 ----------------
with tab_res:
    run = st.session_state.get("run")
    if not run:
        st.info("Run a generation first.")
        st.stop()
    board = run["leaderboard"]
    st.markdown(f"#### Leaderboard · recommended: **{board.iloc[0]['generator']}**")
    st.dataframe(board.drop(columns=["key"]).style.format(precision=3), width="stretch", hide_index=True)
    if run["failed"]:
        st.warning(f"Failed generators: {run['failed']}")
    for k in ["leaderboard", "class_balance", "utility"]:
        if run["figures"].get(k):
            st.image(str(run["figures"][k]))

    pick = st.selectbox("Inspect generator", list(run["results"]), format_func=lambda k: run["results"][k]["display_name"])
    r = run["results"][pick]
    for n in r.get("notes", []):
        st.warning(n)
    f1, f2, f3 = st.tabs(["Fidelity", "Utility", "Privacy risk"])
    with f1:
        a, b, c, d = st.columns(4)
        a.metric("Column shapes", f"{r['fidelity']['column_shape_score']:.3f}")
        b.metric("Pair trends", f"{r['fidelity']['pair_trend_score']:.3f}")
        c.metric("Detection AUC (0.5 ideal)", f"{r['fidelity']['detection_auc']:.3f}")
        d.metric("Fidelity score", f"{r['fidelity']['fidelity_score']:.3f}")
        st.dataframe(r["fidelity"]["column_table"], width="stretch", hide_index=True)
        for k in ["distributions", "association", "pca"]:
            st.image(str(r["figures"][k]))
    with f2:
        if r["utility"].get("available"):
            u = r["utility"]
            a, b, c = st.columns(3)
            a.metric(f"TRTR {u['primary_metric']}", f"{u['trtr_primary']:.3f}")
            b.metric(f"TSTR {u['primary_metric']}", f"{u['tstr_primary']:.3f}")
            c.metric("Utility ratio", f"{u['utility_ratio']:.3f}")
            st.dataframe(u["table"], width="stretch", hide_index=True)
        else:
            st.info("Select a target column to enable downstream evaluation.")
    with f3:
        p = r["privacy"]
        st.markdown(f"**Overall privacy risk: {p['overall_risk'].upper()}**")
        for line in r["privacy_text"]:
            st.markdown(f"- {line}")
        a, b, c, d = st.columns(4)
        a.metric("Exact match rate", f"{p['exact_match_rate'] * 100:.2f}%")
        b.metric("Close record rate", f"{p['close_record_rate'] * 100:.1f}%")
        c.metric("NN disclosure share", f"{p['nn_disclosure_share'] * 100:.1f}%")
        d.metric("MIA AUC", f"{p['mia_auc']:.3f}")
        st.image(str(r["figures"]["privacy"]))

    st.markdown("#### Export")
    syn_path = Path(run["synthetic_dir"]) / f"synthetic_{pick}.csv"
    c1, c2, c3 = st.columns(3)
    c1.download_button(f"Synthetic CSV ({r['display_name']})", syn_path.read_bytes(), syn_path.name, "text/csv")
    c2.download_button("HTML evaluation report", Path(run["report_html"]).read_bytes(),
                       "evaluation_report.html", "text/html")
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        for folder in [run["synthetic_dir"], run["reports_dir"], run["figures_dir"]]:
            for f in Path(folder).glob("*"):
                z.write(f, f"{Path(folder).name}_{Path(folder).parent.name}/{f.name}")
    c3.download_button("Everything (zip)", buf.getvalue(), f"{run['run_id']}.zip", "application/zip")
